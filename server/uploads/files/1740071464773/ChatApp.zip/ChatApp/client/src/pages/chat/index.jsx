import { useAppStore } from "@/store"
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {toast} from "sonner";

const Chat = () => {

  
  const { userInfo } = useAppStore();
  const navigate = useNavigate();
  useEffect(() => {
    //Wenn der User den Profile Setup nicht vollständig durchgeführt hat, dann gebe die Meldung und leite ihn zur Profile Seite.
    if (!userInfo.profileSetup) {
      toast("Please setup Profile to continue.");
      navigate("/profile");
    }
  }, [userInfo, navigate]);


  return (
    <div>
        Chat
    </div>
  )
}

export default Chat;
